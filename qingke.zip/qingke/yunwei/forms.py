from django import forms
from .models import Project,Server,Release

class ServerForm(forms.ModelForm):
    class Meta:
        model = Server
        fields = ['ip','port','user','passwd']


class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['project']

class ReleaseForm(forms.ModelForm):
    class Meta:
        model = Release
        fields = ['wars']



