from django.apps import AppConfig


class YunweiConfig(AppConfig):
    name = 'yunwei'
