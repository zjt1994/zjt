from django.shortcuts import render
from .models import Server
from .forms import ReleaseForm
from django.http import HttpResponseRedirect,Http404
from django.urls import reverse
import paramiko

def release(request,project_id,project_name):
    server = Server.objects.get(id=project_id)
    ip = server.ip
    username = server.user
    password = server.passwd
    project = project_name
    if request.method != 'POST':
        form = ReleaseForm()
    else:
        form = ReleaseForm(request.POST)
        if form.is_valid():
            projects = form.save(commit=False)
            projects.project = project
            projects.ip = ip
            wars = projects.wars
            projects.save()
            fabu(ip,username,password,project,wars)
            return HttpResponseRedirect(reverse('yunwei:project',args=[project_id]))
    context = {"server": server,'project':project, 'form': form}
    return render(request, 'static/release.html', context)

def fabu(topic_ip,username,password,project,wars):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(topic_ip, 22, username=username, password=password, timeout=20)
    stdin, stdout, stderr = ssh.exec_command("/qingke/app_deploy/shells/app_deploy_new %s %s" % (project, wars))
    # result = stdout.readlines()
   # print result
   #  u = []
   #  for i, line in enumerate(stdout):
   #      t = line.strip("\n")
   #      u.append(t)
   #  ssh.close()
   #  return u