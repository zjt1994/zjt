from django.db import models

# Create your models here.
class Server(models.Model):
    '''创建服务器表'''
    ip = models.CharField(max_length=200,unique = True)
    port = models.CharField(max_length=200)
    user = models.CharField(max_length=200)
    passwd = models.CharField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.ip

class Project(models.Model):
    '''创建项目表'''
    ip = models.CharField(max_length=200)
    topic = models.ForeignKey(Server,on_delete=models.CASCADE)
    project = models.CharField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.project

class Release(models.Model):
    '''创建发布表'''
    ip = models.CharField(max_length=200)
    project = models.CharField(max_length=200)
    wars = models.CharField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.project