from django.contrib import admin
from .models import Server,Project

# Register your models here.
admin.site.register(Server)
admin.site.register(Project)