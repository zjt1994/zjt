from django.conf.urls import url, include
from . import views,views1

app_name='yunwei'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^servers/$', views.servers, name='servers'),
    url(r'^servers/(?P<project_id>\d+)/$', views.project, name='project'),
    url(r'^new_servers/$', views.new_servers, name='new_servers'),
    url(r'^new_project/(?P<project_id>\d+)/$', views.new_projects, name='new_projects'),
    url(r'^release/(?P<project_id>\d+)/(?P<project_name>\w+)/$', views1.release, name='release')
]
