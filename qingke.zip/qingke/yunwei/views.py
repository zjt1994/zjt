from django.shortcuts import render
from .models import Server
from .forms import ServerForm,ProjectForm,ReleaseForm
from django.http import HttpResponseRedirect,Http404
from django.urls import reverse
# Create your views here.
def index(request):
    return render(request, 'static/index.html')

def servers(request):
    server = Server.objects.order_by('date_added')
    context = {"servers":server}
    return render(request,'static/servers.html',context)

def project(request,project_id):
    server = Server.objects.get(id=project_id)
    project = server.project_set.order_by('-date_added')
    context = {"server":server,'projects': project}
    return render(request, 'static/project.html', context)

def new_servers(request):
    '''添加服务器'''
    if request.method != 'POST':
        form = ServerForm()
    else:
        form = ServerForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('yunwei:servers'))
    context = {'form': form}
    return render(request, 'static/new_servers.html', context)

def new_projects(request,project_id):
    '''添加一个新项目'''
    server = Server.objects.get(id=project_id)
    if request.method != 'POST':
        form = ProjectForm()
    else:
        form = ProjectForm(request.POST)
        if form.is_valid():
            new_project = form.save(commit=False)
            new_project.topic = server
            new_project.save()
            return HttpResponseRedirect(reverse('yunwei:project',args=[project_id]))
    context = {"server":server,'form': form}
    return render(request, 'static/new_project.html', context)
